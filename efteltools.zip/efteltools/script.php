<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Ontvang de zoekterm van het formulier
  $zoekterm = $_POST['zoekterm'];

  // Verwerk de zoekterm en voer de gewenste acties uit
  // ...

  // Voorbeeld: Toon de zoekterm
  $result = "Je hebt gezocht naar: " . $zoekterm;

  echo $result;
}
?>
