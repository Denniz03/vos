$(document).ready(function() {
    console.log("Document ready!"); // Controleer of dit bericht wordt weergegeven in de console

    // Formulier verzenden
    $('form').submit(function(e) {
        e.preventDefault(); // Voorkom het standaard indienen van het formulier
        var zoekterm = $('input[name="zoekterm"]').val(); // Ontvang de zoekterm uit het formulier
        $.ajax({
            type: 'POST',
            url: 'script.php',
            data: { zoekterm: zoekterm },
            success: function(result) {
                console.log(result);
                $('#elliResults').html(result); // Bijwerk het resultaat in de main tag
            },
            error: function(xhr, status, error) {
                console.log(error); // Toon eventuele fouten in de console
            }
        });
        return false; // Stop het standaardgedrag van het formulier
    });
});

function toggleUserPopup() {
    var popup = $('#user-popup-content');
    popup.toggle();
}

function loadForm(formName) {
    $.get(formName + '.html', function(data) {
        $('#main-content').html(data);
    });
}
